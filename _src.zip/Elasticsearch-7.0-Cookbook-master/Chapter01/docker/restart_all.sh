 amm ../stop_all.sc && amm ../remove_all_instances.sc
 docker rmi multinodes_elasticsearch3 multinodes_elasticsearch multinodes_elasticsearch2
 docker-compose up -d
