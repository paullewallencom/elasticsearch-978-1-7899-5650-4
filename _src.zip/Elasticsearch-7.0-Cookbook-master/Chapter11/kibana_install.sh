wget https://artifacts.elastic.co/downloads/kibana/kibana-7.0.0-linux-x86_64.tar.gz
tar xfvz kibana-7.0.0-linux-x86_64.tar.gz

